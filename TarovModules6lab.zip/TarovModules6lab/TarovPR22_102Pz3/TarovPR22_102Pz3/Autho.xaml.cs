﻿using TarovPR22_102Pz3.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace TarovPR22_102Pz3
{
    public partial class Autho : Page
    {
        int click;

        public Autho()
        {
            InitializeComponent();
            click = 0;
        }
        public static string HashPassword(string password)
        {
            using (SHA256 shs256Hash = SHA256.Create())
            {
                byte[] sourceBytePassword = Encoding.UTF8.GetBytes(password);
                byte[] hash = shs256Hash.ComputeHash(sourceBytePassword);
                return BitConverter.ToString(hash).Replace("-", String.Empty);
            }
        }
        private void btnEnterGuest_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Client(null, null));
        }

        private void GenerateCapctcha()
        {
            tbCaptcha.Visibility = Visibility.Visible;
            tblCaptcha.Visibility = Visibility.Visible;

            string capctchaText = CaptchaGenerator.GenerateCaptchaText(6);
            tblCaptcha.Text = capctchaText;
            tblCaptcha.TextDecorations = TextDecorations.Strikethrough;
        }

        private void btnEnter_Click(object sender, RoutedEventArgs e)
        {
            click += 1;
            string login = tbLogin.Text.Trim();
            string password = HashPassword(tbPassword.Text.Trim());
            Furniture_centerEntities db = new Furniture_centerEntities();
            var user = db.Auth.Where(x => x.Username == login && x.Password == password).FirstOrDefault();
            if (click == 1)
            {
                if (user != null)
                {
                    string roleText = GetRoleText(user.RoleID);
                    MessageBox.Show($"Вы вошли под: {roleText}");
                    LoadPage(user.RoleID.ToString(), user);
                }
                else
                {
                    MessageBox.Show("Вы ввели логин или пароль неверно!");
                    GenerateCapctcha();
                }
            }
            else if (click > 1)
            {
                if (user != null && tbCaptcha.Text == tblCaptcha.Text)
                {
                    string roleText = GetRoleText(user.RoleID);
                    MessageBox.Show($"Вы вошли под: {roleText}");
                    LoadPage(user.RoleID.ToString(), user);
                }
                else
                {
                    MessageBox.Show("Введите данные заново!");
                    GenerateCapctcha();
                }
            }
        }
        private string GetRoleText(int roleID)
        {
            switch (roleID)
            {
                case 1:
                    return "Клиент";
                case 2:
                    return "Бухгалтер";
                case 3:
                    return "Логист";
                default:
                    return "Неизвестная роль";
            }
        }

        private void LoadPage(string _role, Auth user)
        {
            click = 0;
            tblCaptcha.Visibility = Visibility.Hidden;
            tbCaptcha.Clear();
            tbLogin.Clear();
            tbPassword.Clear();
            switch (_role)
            {
                case "1":
                    NavigationService.Navigate(new Client(user, _role));
                    break;
                case "2":
                    NavigationService.Navigate(new Buhgalter(user, _role));
                    break;
                case "3":
                    NavigationService.Navigate(new Logist(user, _role));
                    break;
                default:
                    MessageBox.Show("Роль не распознана!");
                    break;
            }
        }
    }
}
