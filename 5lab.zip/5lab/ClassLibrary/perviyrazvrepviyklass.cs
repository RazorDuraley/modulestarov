﻿using System;
using System.Security.Cryptography;
using System.Text;

namespace ClassLibrary
{
    public static class PasswordHasher
    {
        public static string HashPassword(string password)
        {
            // Создаем объект SHA256
            using (SHA256 sha256Hash = SHA256.Create())
            {
                // Преобразуем пароль в байты и вычисляем хеш
                byte[] sourceBytePassw = Encoding.UTF8.GetBytes(password);
                byte[] hashSourceBytePassw = sha256Hash.ComputeHash(sourceBytePassw);

                // Преобразуем байты в строку в шестнадцатичном формате
                StringBuilder hashPassw = new StringBuilder();
                foreach (byte b in hashSourceBytePassw)
                {
                    hashPassw.Append(b.ToString("x2"));
                }

                return hashPassw.ToString();
            }
        }
    }
}