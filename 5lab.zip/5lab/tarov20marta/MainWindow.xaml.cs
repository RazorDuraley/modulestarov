﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using Excel = Microsoft.Office.Interop.Excel;
namespace tarov20marta
{
    public class Book
    {
        public string Title { get; set; }
        public string Author { get; set; }
        public int GenreId { get; set; }
        public string Genre { get; set; }
    }

    public class Genre
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }

    public partial class MainWindow : Window
    {
        private ObservableCollection<Book> books;
        private ObservableCollection<Genre> genres;
        private ICollectionView booksView;

        public MainWindow()
        {
            InitializeComponent();
            LoadData();
        }

        private void LoadData()
        {
            string connectionString = "Server=10.137.203.94,1433;Database=Tarov20marta;User Id=22.102-30;Password=Passw0rd;MultipleActiveResultSets=True;";
            books = new ObservableCollection<Book>();
            genres = new ObservableCollection<Genre>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    string genreQuery = "SELECT Id, Name FROM Genres";
                    using (SqlCommand genreCommand = new SqlCommand(genreQuery, connection))
                    {
                        using (SqlDataReader genreReader = genreCommand.ExecuteReader())
                        {
                            while (genreReader.Read())
                            {
                                genres.Add(new Genre
                                {
                                    Id = (int)genreReader["Id"],
                                    Name = genreReader["Name"].ToString()
                                });
                            }
                        }
                    }
                    GenreComboBox.ItemsSource = genres;

                    string bookQuery = "SELECT b.Title, b.Author, b.GenreId, g.Name AS Genre FROM Books b JOIN Genres g ON b.GenreId = g.Id";
                    using (SqlCommand bookCommand = new SqlCommand(bookQuery, connection))
                    {
                        using (SqlDataReader bookReader = bookCommand.ExecuteReader())
                        {
                            while (bookReader.Read())
                            {
                                books.Add(new Book
                                {
                                    Title = bookReader["Title"].ToString(),
                                    Author = bookReader["Author"].ToString(),
                                    GenreId = (int)bookReader["GenreId"],
                                    Genre = bookReader["Genre"].ToString()
                                });
                            }
                        }
                    }

                    BooksDataGrid.ItemsSource = books;
                    booksView = CollectionViewSource.GetDefaultView(books);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка: " + ex.Message);
                }
            }
        }

        private void SearchTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            FilterBooks();
        }

        private void GenreComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            FilterBooks();
        }

        private void FilterBooks()
        {
            string searchText = SearchTextBox.Text.ToLower();
            var selectedGenre = GenreComboBox.SelectedItem as Genre;

            booksView.Filter = book =>
            {
                var b = book as Book;
                bool matchesSearch = b.Title.ToLower().Contains(searchText) || b.Author.ToLower().Contains(searchText);
                bool matchesGenre = selectedGenre == null || b.GenreId == selectedGenre.Id;

                return matchesSearch && matchesGenre;
            };
        }

        private void BooksDataGrid_Sorting(object sender, DataGridSortingEventArgs e)
        {
            var column = e.Column.Header.ToString();
            if (column == "Title")
            {
                booksView.SortDescriptions.Clear();
                booksView.SortDescriptions.Add(new SortDescription("Title", e.Column.SortDirection == ListSortDirection.Ascending ? ListSortDirection.Descending : ListSortDirection.Ascending));
                e.Handled = true;
            }
            else if (column == "Author")
            {
                booksView.SortDescriptions.Clear();
                booksView.SortDescriptions.Add(new SortDescription("Author", e.Column.SortDirection == ListSortDirection.Ascending ? ListSortDirection.Descending : ListSortDirection.Ascending));
                e.Handled = true;
            }
        }
    }
}